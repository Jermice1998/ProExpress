How to Run

-Download/Install the following
-Python (I used v3.9.1)
-Django (I used v4.0.3)
-PIP (for python modules installation)

Setup/Installation

1.Download and Extract the provided source code zip file.
2.Open your Code Editor(Visual Studio Code), change the working directory to the extracted source code folder. 
3.Run the Terminal in Visual Studio Code.
4. Run the following commands:
	-pip install Django
	-pip install -r requirements.txt
	-python manage.py migrate
	-python manage.py runserver
5. Open a web browser and browse http://127.0.0.1:8000/

Access Information
username: adminproexpress
password: helloadmin1234